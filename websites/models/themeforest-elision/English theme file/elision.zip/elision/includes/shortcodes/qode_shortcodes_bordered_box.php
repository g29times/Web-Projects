
<div id="qode_shortcode_form_wrapper">
<form id="qode_shortcode_form" name="qode_shortcode_form" method="post" action="">
	<div class="input">
		<label>Border Color</label>
		<div class="colorSelector"><div style=""></div></div>
		<input type="text" name="border_color" id="border_color" value="" size="10" maxlength="10" />
	</div>
	<div class="input">
		<label>Background Color</label>
		<div class="colorSelector"><div style=""></div></div>
		<input type="text" name="background_color" id="background_color" value="" size="10" maxlength="10" />
	</div>
	<div class="input">
		<input type="submit" name="Insert" id="qode_insert_shortcode_button" value="Submit" />
	</div>
</form>
</div>