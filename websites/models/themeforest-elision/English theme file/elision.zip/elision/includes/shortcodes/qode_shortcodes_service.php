<div id="qode_shortcode_form_wrapper">
<form id="qode_shortcode_form" name="qode_shortcode_form" method="post" action="">
	<div class="input">
		<label>Type</label>
		<select name="type" id="type">
			<option value=""></option>
			<option value="top">top</option>
			<option value="left">left</option>
		</select>
	</div>
	<div class="input">
		<label>Title</label>
		<input name="title" id="title" value="" />
	</div>
	<div class="input">
		<label>Title Color</label>
		<input name="color" id="color" value="" />
	</div>
	<div class="input">
		<label>Link</label>
		<input name="link" id="link" value="" />
	</div>
	<div class="input">
		<label>Target</label>
		<select name="target" id="target">
			<option value=""></option>
			<option value="_self">Self</option>
			<option value="_blank">Blank</option>
		</select>
	</div>
    <div class="input">
		<label>Animate</label>
		<select name="animate" id="animate">
			<option value="yes">Yes</option>
			<option value="no">No</option>
		</select>
	</div>
	<div class="input">
		<input type="submit" name="Insert" id="qode_insert_shortcode_button" value="Submit" />
	</div>
</form>
</div>